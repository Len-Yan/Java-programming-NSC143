/**
 * basic interface for view part
 * 
 * @author Lengfan Yan
 * @version Assignment 3, 2015/10/24
 */
public interface VIEW{
  
  
  // check changes for viewer
 public void viewChange(); 
 
  /**
   * Notify view to update its display of the DrawingBoard
   */
 // public void notifychange();
  
}